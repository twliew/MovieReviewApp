let config = {
  host    : 'ec2-18-216-101-119.us-east-2.compute.amazonaws.com',
  user    : 'twliew',
  password: 'MSCI245',
  database: 'twliew'
};
 
export default config;